import { Injectable } from '@angular/core';
import { Order } from './order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  orderList:Array<any> = [];

  constructor() { }

  addItem(productName : string, quantity : number) {
    // Fill the code
    
  }

  getOrder() {
    // Fill the code
    
  }

  calculateBill() {
    // Fill the code
    
    return 0;
  }
}
