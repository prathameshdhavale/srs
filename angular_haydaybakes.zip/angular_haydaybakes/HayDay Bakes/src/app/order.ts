export class Order {
    constructor(public productName : string, public quantity : number) {}
}
