import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OrderService } from '../order.service';
import { FormsModule } from '@angular/forms';
import { Order } from '../order';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})

export class ProductsComponent implements OnInit {

  flag = 0;
  constructor(private orderService : OrderService, private roter : Router, private activatedRoute : ActivatedRoute) { } 

  ngOnInit(): void {
    // Fill the code
  }

  addItem(productName:string, quantity : any) {
    // Fill the code
  }

}
